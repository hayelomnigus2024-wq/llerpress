<?php
/**
 * Demo course data for the setup wizard.
 *
 * @since 4.4.7
 * @version 1.0.0
 */
return <<<JSON
{
    "courses": [
        {
            "title": "Introduction to LearnPress: Building Your Learning Management System",
            "excerpt": "Learn the essential steps for creating and launching an online learning site with LearnPress.",
            "content": "<p>This introductory course explains how LearnPress organizes courses, lessons, students, and learning settings. Follow the lessons to prepare a practical LMS foundation that can grow with your academy.</p>",
            "status": "publish",
            "section": {
                "title": "LearnPress Foundations",
                "description": "A guided introduction to planning, configuring, and publishing a LearnPress LMS.",
                "lessons": [
                    {
                        "title": "Define Your LMS Goals",
                        "content": "<p>Identify your learners, the skills they need, and the result each course should deliver. Clear goals help you choose the right course structure and content.</p>",
                        "duration": "10 minute"
                    },
                    {
                        "title": "Install and Configure LearnPress",
                        "content": "<p>Review the core settings, required pages, currency, and email options that prepare LearnPress for everyday use.</p>",
                        "duration": "15 minute"
                    },
                    {
                        "title": "Understand Courses, Sections, and Lessons",
                        "content": "<p>Learn how a course contains sections and how each section groups lessons into a clear learning path.</p>",
                        "duration": "12 minute"
                    },
                    {
                        "title": "Prepare the Student Experience",
                        "content": "<p>Check course presentation, enrollment behavior, navigation, and the profile area from a student's point of view.</p>",
                        "duration": "12 minute"
                    },
                    {
                        "title": "Publish Your First Learning Path",
                        "content": "<p>Review the curriculum, confirm visibility, and publish a simple course that students can start using.</p>",
                        "duration": "10 minute"
                    }
                ]
            }
        },
        {
            "title": "Create and Manage Engaging LMS Websites with LearnPress",
            "excerpt": "Build a well-organized learning website and keep students engaged throughout their courses.",
            "content": "<p>This course focuses on planning an engaging academy, organizing useful content, and maintaining a consistent experience for students and instructors.</p>",
            "status": "publish",
            "section": {
                "title": "Build an Engaging Academy",
                "description": "Practical lessons for designing, operating, and improving a LearnPress website.",
                "lessons": [
                    {
                        "title": "Plan the Learning Website",
                        "content": "<p>Map the academy's audience, course topics, navigation, and calls to action before creating content.</p>",
                        "duration": "10 minute"
                    },
                    {
                        "title": "Structure Course Content Clearly",
                        "content": "<p>Break a topic into focused lessons and arrange them in an order that is easy for students to follow.</p>",
                        "duration": "15 minute"
                    },
                    {
                        "title": "Encourage Student Engagement",
                        "content": "<p>Use clear outcomes, practical activities, progress cues, and useful feedback to keep learners involved.</p>",
                        "duration": "12 minute"
                    },
                    {
                        "title": "Manage Courses and Learners",
                        "content": "<p>Review enrollment, student progress, instructor responsibilities, and routine course updates.</p>",
                        "duration": "15 minute"
                    },
                    {
                        "title": "Improve the Academy Over Time",
                        "content": "<p>Collect feedback, refresh outdated lessons, and simplify areas where learners commonly lose momentum.</p>",
                        "duration": "10 minute"
                    }
                ]
            }
        },
        {
            "title": "How To Sell In-Person Courses With LearnPress",
            "excerpt": "Use LearnPress to present, sell, and manage instructor-led classes held at a physical location.",
            "content": "<p>This course shows how to package an in-person class as a LearnPress course, communicate logistics, collect registrations, and manage the learner journey.</p>",
            "status": "publish",
            "section": {
                "title": "Launch an In-Person Course",
                "description": "Set up the offer, schedule, payments, enrollment, and delivery workflow.",
                "lessons": [
                    {
                        "title": "Design the In-Person Offer",
                        "content": "<p>Define the class outcome, audience, delivery format, capacity, and prerequisites before publishing the offer.</p>",
                        "duration": "10 minute"
                    },
                    {
                        "title": "Add Schedule and Location Details",
                        "content": "<p>Provide dates, session times, venue information, access instructions, and a clear cancellation policy.</p>",
                        "duration": "10 minute"
                    },
                    {
                        "title": "Configure Pricing and Payment",
                        "content": "<p>Choose a price, configure an available payment gateway, and explain what the registration fee includes.</p>",
                        "duration": "12 minute"
                    },
                    {
                        "title": "Manage Enrollment and Communication",
                        "content": "<p>Track registrations and send learners the confirmation, preparation details, and reminders they need.</p>",
                        "duration": "12 minute"
                    },
                    {
                        "title": "Deliver and Follow Up",
                        "content": "<p>Prepare attendance, learning materials, post-class resources, and a simple follow-up process.</p>",
                        "duration": "10 minute"
                    }
                ]
            }
        },
        {
            "title": "Create an LMS Website with LearnPress",
            "excerpt": "Follow a practical path from a new WordPress site to a working online academy.",
            "content": "<p>This course walks through the main decisions and setup tasks required to turn a WordPress website into a usable LearnPress learning platform.</p>",
            "status": "publish",
            "section": {
                "title": "From Website to LMS",
                "description": "Build the site foundation, configure LearnPress, create a course, and prepare for launch.",
                "lessons": [
                    {
                        "title": "Prepare WordPress for Your Academy",
                        "content": "<p>Choose a clear site structure, confirm the basic WordPress settings, and prepare the pages learners will use.</p>",
                        "duration": "10 minute"
                    },
                    {
                        "title": "Install LearnPress and Run Setup",
                        "content": "<p>Install the plugin and complete the initial setup for learning experience, pages, payments, and emails.</p>",
                        "duration": "15 minute"
                    },
                    {
                        "title": "Configure Core LMS Settings",
                        "content": "<p>Review course behavior, profile access, checkout, currency, and notification settings before adding content.</p>",
                        "duration": "15 minute"
                    },
                    {
                        "title": "Create and Review a Course",
                        "content": "<p>Add a course, organize its curriculum, preview the student experience, and correct missing information.</p>",
                        "duration": "20 minute"
                    },
                    {
                        "title": "Launch and Extend the Website",
                        "content": "<p>Publish the academy, test enrollment, and evaluate optional extensions only when the learning workflow requires them.</p>",
                        "duration": "12 minute"
                    }
                ]
            }
        },
        {
            "title": "Introduction LearnPress – LMS Plugin",
            "excerpt": "Explore the core LearnPress concepts used to create and manage online courses in WordPress.",
            "content": "<p>This beginner-friendly course introduces the LearnPress workflow and the main tools used by administrators, instructors, and students.</p>",
            "status": "publish",
            "section": {
                "title": "LearnPress Essentials",
                "description": "Understand the plugin, build a curriculum, and prepare a simple course for learners.",
                "lessons": [
                    {
                        "title": "What LearnPress Provides",
                        "content": "<p>Explore the roles of courses, lessons, students, instructors, orders, and settings within a LearnPress academy.</p>",
                        "duration": "8 minute"
                    },
                    {
                        "title": "Navigate the LearnPress Dashboard",
                        "content": "<p>Locate the main administration screens and understand where course content and global behavior are managed.</p>",
                        "duration": "10 minute"
                    },
                    {
                        "title": "Build a Simple Curriculum",
                        "content": "<p>Create a course section and add focused lessons that guide learners toward a specific outcome.</p>",
                        "duration": "15 minute"
                    },
                    {
                        "title": "Configure Enrollment and Access",
                        "content": "<p>Review free and paid enrollment paths, profile access, and the settings that control how students begin learning.</p>",
                        "duration": "12 minute"
                    },
                    {
                        "title": "Review, Publish, and Maintain",
                        "content": "<p>Check course details, publish the content, monitor learner use, and update lessons as the topic changes.</p>",
                        "duration": "10 minute"
                    }
                ]
            }
        }
    ]
}
JSON;
